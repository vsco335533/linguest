/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Radio,
  RadioGroup,
  FormControlLabel,
  Button,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import CircularProgress from "@mui/material/CircularProgress";
import { fetchQuizDetails, sendQuizScore } from "../../services/moduleApi";

const QuizPage = () => {
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [selectedOption, setSelectedOption] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [questionCount, setQuestionCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);
  const navigate = useNavigate();

  const fetchNextQuestion = async () => {
    console.log(window.sessionStorage.getItem("user_id"));

    try {
      let payload;
      if (session === null) {
        payload = {
          user_id: parseInt(window.sessionStorage.getItem("user_id")),
        };
      } else {
        payload = {
          user_id: parseInt(window.sessionStorage.getItem("user_id")),
          session_id: session,
        };
      }

      const questionData = await fetchQuizDetails(payload);
      console.log(questionData.sessionId, "dataq");

      setCurrentQuestion(questionData);
      console.log(questionData, "questionData");
      setSession(questionData.sessionId);
    } catch (error) {
      console.error("Error fetching quiz details:", error);
    } finally {
      setLoading(false);
    }
  };
  const submitScore = async () => {
    try {
      await sendQuizScore(score);
    } catch (error) {
      console.error("Error submitting quiz score:", error);
    }
  };

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleSubmit = async () => {
    if (
      currentQuestion?.options.includes(selectedOption) &&
      currentQuestion?.options.includes(currentQuestion?.correctAnswer) &&
      selectedOption === currentQuestion?.correctAnswer
    ) {
      setScore((prevScore) => prevScore + 1);
    }
    //   if (selectedOption === currentQuestion?.correctAnswer) {
    //     setScore((prevScore) => prevScore + 1);
    //   }
    setQuestionCount((prevCount) => prevCount + 1);
    setSelectedOption("");
    setLoading(true);
    // console.log(questionCount,"quesifout")

    if (questionCount + 1 === 20) {
      console.log(questionCount, "ques");
      setIsSubmitted(true);
      await submitScore();
      setLoading(false);
    } else {
      await fetchNextQuestion();
      setSession(session);
    }
  };

  const handleQuiz = () => {
    navigate("/HomePage");
  };

  useEffect(() => {
    fetchNextQuestion();
  }, []);

  return (
    <>
      {loading ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <CircularProgress size="50px" />
        </Box>
      ) : (
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: "85%", sm: "55%", md: "55%" },
            bgcolor: "#FFFFFF",
            boxShadow: 3,
            borderRadius: "16px",
            p: { xs: 2, sm: 3, md: 4 },
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            maxHeight: "80vh",
          }}
        >
          {!isSubmitted ? (
            currentQuestion && (
              <>
                <Box sx={{ textAlign: "left", mb: 3 }}>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: "500",
                      fontFamily: "Montserrat",
                      fontSize: "32px",
                      color: "#D72518",
                    }}
                  >
                    Question {questionCount + 1}/20
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{
                      fontWeight: "400",
                      fontFamily: "Montserrat",
                      fontSize: "28px",
                      color: "#000000",
                    }}
                  >
                    {currentQuestion.question}
                  </Typography>
                </Box>
                <RadioGroup
                  value={selectedOption}
                  onChange={handleOptionChange}
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                    mb: 4,
                  }}
                >
                  {currentQuestion.options.map((option, index) => (
                    <FormControlLabel
                      key={index}
                      value={option}
                      control={<Radio sx={{ fontSize: 34 }} />}
                      label={
                        <Typography
                          sx={{ fontSize: 20, fontFamily: "Montserrat" }}
                        >
                          {option}
                        </Typography>
                      }
                    />
                  ))}
                </RadioGroup>
                <Box sx={{ textAlign: "center" }}>
                  <Button
                    variant="contained"
                    onClick={handleSubmit}
                    disabled={!selectedOption}
                    sx={{
                      textAlign: "center",
                      width: 186,
                      height: 62,
                      borderRadius: "50px",
                      backgroundColor: "#2E8BBA",
                      "&:hover": { backgroundColor: "#2E8BBA" },
                      fontSize: 24,
                      fontFamily: "Montserrat",
                      font: "bold",
                      paddingBottom: "10px",
                    }}
                  >
                    Next
                  </Button>
                </Box>
              </>
            )
          ) : (
            <>
              <Typography
                variant="h4"
                sx={{ mb: 2, textAlign: "center", fontFamily: "Montserrat" }}
              >
                Quiz Completed!
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  mb: 4,
                  textAlign: "center",
                  color: "#555",
                  fontFamily: "Montserrat",
                  fontSize: "25px",
                }}
              >
                Your Score: {score} / 20
              </Typography>
              <Box sx={{ textAlign: "center" }}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleQuiz}
                  sx={{
                    width: 186,
                    height: 62,
                    borderRadius: "50px",
                    backgroundColor: "#2E8BBA",
                    "&:hover": { backgroundColor: "#2E8BBA" },
                    fontSize: 14,
                    fontFamily: "Montserrat",
                    font: "bold",
                    paddingBottom: "10px",
                  }}
                >
                  Move To HomePage
                </Button>
              </Box>
            </>
          )}
        </Box>
      )}
    </>
  );
};

export default QuizPage;
