
/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Typography } from "@mui/material";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const LineChart = ({ graphdata, graphDataOverall }) => {
  const [chartOptions, setChartOptions] = useState({
    responsive: true,
    maintainAspectRatio: false,
    layout: {
      padding: {
        right: 0,
        left: 0,
        bottom: 0,
      },
    },
    plugins: {
      legend: {
        display: true,
        position: window.innerWidth < 768 ? "bottom" : "right", // Default position based on screen width
        labels: {
          usePointStyle: true,
          
          boxWidth: 30,
          boxHeight: 10,
          padding: 20,
          font: {
            size: 15,
            fontFamily: "Montserrat",
          },
          color: "#000000",
        },
      },
    },
    scales: {
      x: {
        title: {
          display: true,
        },
      },
      y: {
        min: 0,
        max: 100,
        ticks: {
          stepSize: 10,
        },
        title: {
          display: true,
          text: "Percentage (%)",
        },
      },
    },
  });

  useEffect(() => {
    const handleResize = () => {
      setChartOptions((prevOptions) => ({
        ...prevOptions,
        plugins: {
          ...prevOptions.plugins,
          legend: {
            ...prevOptions.plugins.legend,
            position: window.innerWidth < 768 ? "bottom" : "right", // Update position dynamically
          },
        },
      }));
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const metricData = {
    labels: graphdata?.attempt_numbers,
    datasets: [
      {
        label: "Complexity",
        data: graphdata?.complexity_percentage,
        borderColor: "#8979FF",
        backgroundColor: "rgba(137, 121, 255, 0.2)",
        fill: false,
      },
      {
        label: "Discourse Length",
        data: graphdata?.discourse_percentage,
        borderColor: "#537FF1",
        backgroundColor: "rgba(83, 127, 241, 0.2)",
        fill: false,
      },
      {
        label: "Grammatical Measure",
        data: graphdata?.grammar_error_percentage,
        borderColor: "#FF928A",
        backgroundColor: "rgba(255, 146, 138, 0.2)",
        fill: false,
      },
      {
        label: "Idiomatic Expressiveness",
        data: graphdata?.idiomatic_percentage,
        borderColor: "#FFAE4C",
        backgroundColor: "rgba(255, 174, 76, 0.2)",
        fill: false,
      },
      {
        label: "Contextual Adaptability",
        data: graphdata?.overall_efficiency,
        borderColor: "#3CC3DF",
        backgroundColor: "rgba(60, 195, 223, 0.2)",
        fill: false,
      },
      {
        label: "Politeness",
        data: graphdata?.politeness_percentage,
        borderColor: "#6FD195",
        backgroundColor: "rgba(111, 209, 149, 0.2)",
        fill: false,
      },
    ],
  };

  const OverallData = {
    labels: graphDataOverall?.attempt_numbers,
    datasets: [
      {
        label: "Overall Performance",
        data: graphDataOverall?.overall_efficiency,
        borderColor: "#8979FF",
        backgroundColor: "rgba(137, 121, 255, 0.2)",
        fill: false,
      },
    ],
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        width: "96%",
        height: "416px",
        margin: "0 auto",
        padding: "20px",
        borderRadius: "10px",
        backgroundColor: "#FFFFFF",
      }}
    >
      <Typography
        variant="h6"
        style={{
          textAlign: "left",
          color: "black",
          marginBottom: "5px",
          fontFamily: "Montserrat",
          fontSize: "24px",
          display: "flex",
          whiteSpace: "nowrap",
          overflow: "visible",
          textOverflow: "ellipsis",
        }}
      >
        {graphdata ? "Analytic Dashboard" : "Performance Trend"}
      </Typography>

      <div style={{ flexGrow: 1 }}>
        <Line data={graphdata ? metricData : OverallData} options={chartOptions} />
      </div>
    </div>
  );
};

<style>
  {`
    /* Mobile Styles (up to 480px width) */
    @media (max-width: 480px) {
      div {
        width: 100%;  /* Make container width 100% */
        padding: 10px; /* Reduce padding on mobile */
        height: auto;  /* Allow height to adjust as needed */
      }

      .MuiTypography-h6 {
        font-size: 18px; /* Smaller font size for smaller screens */
        margin-bottom: 10px;
      }
    }

    /* Tablet Styles (481px to 768px width) */
    @media (max-width: 768px) {
      div {
        width: 90%;  /* Adjust container width for tablets */
        padding: 15px; /* Adjust padding for tablets */
      }

      .MuiTypography-h6 {
        font-size: 20px; /* Slightly smaller font size for tablet screens */
      }
    }

    /* Laptop Styles (769px to 1024px width) */
    @media (max-width: 1024px) {
      div {
        width: 80%;  /* Adjust container width for laptops */
        padding: 20px; /* Padding for laptop screens */
      }

      .MuiTypography-h6 {
        font-size: 22px; /* Font size for larger tablets and small laptops */
      }
    }

    /* Desktop Styles (above 1024px width) */
    @media (min-width: 1025px) {
      div {
        width: 96%;  /* Use the original width for larger screens */
        padding: 20px;
      }

      .MuiTypography-h6 {
        font-size: 24px; /* Default font size for desktop */
      }
    }
  `}
</style>
export default LineChart;




