/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import {
  Typography, Box, Button, Container, IconButton,
  LinearProgress, Tooltip
} from "@mui/material";
import AccountCircle from "@mui/icons-material/AccountCircle";
import LockIcon from "@mui/icons-material/Lock";
import { useNavigate } from "react-router-dom";
import styles from "./HomePage.module.css";
import Popover from "@mui/material/Popover";
import LineChart from "./LineChart";
import { getDashboardDetails, profilegrading, getUserProgress } from "../../services/moduleApi";

const HomePage = () => {
  const navigate = useNavigate();
  const [graphdatametrics, setGraphDataMetrics] = useState();
  const [overallGraphData, setOverallGraphData] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const [cefrrating, setCEFRRating] = useState();
  const [sessionExpired, setSessionExpired] = useState(false);
  const [progress, setProgress] = useState(null);

  useEffect(() => {
    fetchCEFRRating();
    fetchDashboardData();
    fetchProgress();
  }, []);

  const fetchCEFRRating = async () => {
    const userId = window.sessionStorage.getItem("user_id");
    try {
      const cefrData = await profilegrading(userId);
      window.sessionStorage.setItem("cefrrating", cefrData.data.cefr_level);
      setCEFRRating(cefrData.data.cefr_level);
    } catch (error) {
      if (error.response && error.response.status === 401) {
        setSessionExpired(true);
      } else {
        console.error("Error fetching CEFR rating:", error);
      }
    }
  };

  const fetchDashboardData = async () => {
    const user_Id = window.sessionStorage.getItem("user_id");
    try {
      const dashboardData = await getDashboardDetails(user_Id);
      setGraphDataMetrics(dashboardData.data.metrics);
      setOverallGraphData(dashboardData.data.attempts);
    } catch (error) {
      if (error.response && error.response.status === 401) {
        setSessionExpired(true);
      } else {
        console.error("Error fetching dashboard data:", error);
      }
    }
  };

  const fetchProgress = async () => {
    const userId = window.sessionStorage.getItem("user_id");
    try {
      const res = await getUserProgress(userId);
      setProgress(res.data);
      // Keep session storage in sync so ChatPage can read the level
      if (res.data?.english_level) {
        window.sessionStorage.setItem("cefrrating", res.data.english_level + ": " + res.data.level_name);
      }
    } catch (error) {
      console.error("Error fetching progress:", error);
    }
  };

  const handleClick = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);
  const handleRefreshSession = () => window.location.reload();

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;

  const handleQuiz = () => navigate("/quizPage");
  const handleLearn = () => navigate("/ChatPageIntro");
  const handleLogout = () => {
    window.localStorage.clear();
    window.sessionStorage.clear();
    navigate("/");
  };

  const storyProgress = progress
    ? progress.total_stories > 0
      ? Math.round((progress.stories_completed / progress.total_stories) * 100)
      : 0
    : null;

  return (
    <Box className={styles.mainContainer}>
      {sessionExpired && (
        <>
          <Box className={styles.sessionExpiredOverlay}></Box>
          <Box className={styles.sessionExpiredBox}>
            <Typography variant="h5" color="error">
              Your session has expired. Please refresh to continue.
            </Typography>
            <Button variant="contained" color="primary" onClick={handleRefreshSession}>
              Refresh
            </Button>
          </Box>
        </>
      )}

      <Box className={styles.header}>
        <Typography variant="h3" style={{ color: "#5FB0FF", fontWeight: 600 }}>
          <span style={{ marginLeft: "30px" }}>Welcome!</span>
        </Typography>

        <div>
          <IconButton edge="start" color="inherit" aria-label="profile" onClick={handleClick}>
            {cefrrating ? (
              <div className={styles.cerfIcon}>
                <h5>{cefrrating.charAt(0) + cefrrating.charAt(1)}</h5>
              </div>
            ) : (
              <AccountCircle style={{ fontSize: 70, color: "#5FB0FF" }} />
            )}
          </IconButton>

          <Popover
            id={id}
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
            transformOrigin={{ vertical: "top", horizontal: "center" }}
          >
            <Typography sx={{ p: 2, cursor: "pointer" }} variant="h4" onClick={handleLogout}>
              LogOut
            </Typography>
          </Popover>
        </div>
      </Box>

      <Container className={styles.TwoContainers}>
        {/* Learn Card */}
        <Box className={styles.LearnandQuizBox}>
          <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "space-evenly", height: "100%" }}>
            <div style={{ display: "flex", alignItems: "center", flexDirection: "column" }}>
              <Typography fontSize={32} fontWeight={500}>Start your Learning</Typography>
              <Typography fontSize={32} fontWeight={500}>Journey</Typography>
              {progress && (
                <Typography fontSize={14} sx={{ mt: 1, color: "#888" }}>
                  Level: {progress.english_level} — {progress.level_name}
                </Typography>
              )}
            </div>

            {/* Story progress bar */}
            {progress && progress.total_stories > 0 && (
              <Box sx={{ px: 3 }}>
                <Typography fontSize={14} sx={{ mb: 0.5, color: "#555" }}>
                  Stories: {progress.stories_completed} / {progress.total_stories}
                </Typography>
                <LinearProgress
                  variant="determinate"
                  value={storyProgress}
                  sx={{ height: 10, borderRadius: 5 }}
                />
              </Box>
            )}

            <div style={{ display: "flex", justifyContent: "center" }}>
              <Button
                className={styles.LearnandQuizButton}
                variant="contained"
                sx={{ borderRadius: "40px" }}
                onClick={handleLearn}
              >
                <h2>Learn</h2>
              </Button>
            </div>
          </Box>
        </Box>

        {/* Quiz Card */}
        <Box className={styles.LearnandQuizBox}>
          <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "space-evenly", height: "100%" }}>
            <div style={{ display: "flex", alignItems: "center", flexDirection: "column" }}>
              <Typography fontSize={32} fontWeight={500}>
                {progress?.quiz_unlocked ? "Take your Level Quiz!" : "Complete all stories"}
              </Typography>
              <Typography fontSize={32} fontWeight={500}>
                {progress?.quiz_unlocked ? "to level up" : "to unlock Quiz"}
              </Typography>
              {progress && !progress.quiz_unlocked && (
                <Typography fontSize={14} sx={{ mt: 1, color: "#e57373" }}>
                  {progress.total_stories - progress.stories_completed} stor
                  {progress.total_stories - progress.stories_completed === 1 ? "y" : "ies"} remaining
                </Typography>
              )}
            </div>

            <div style={{ display: "flex", justifyContent: "center" }}>
              <Tooltip
                title={progress && !progress.quiz_unlocked ? "Complete all stories at your level first" : ""}
                arrow
              >
                <span>
                  <Button
                    className={styles.LearnandQuizButton}
                    variant="contained"
                    sx={{ borderRadius: "40px", opacity: progress && !progress.quiz_unlocked ? 0.5 : 1 }}
                    onClick={handleQuiz}
                    disabled={progress !== null && !progress?.quiz_unlocked}
                    startIcon={progress && !progress.quiz_unlocked ? <LockIcon /> : null}
                  >
                    <h2>Quiz</h2>
                  </Button>
                </span>
              </Tooltip>
            </div>
          </Box>
        </Box>
      </Container>

      <Box className={styles.AnalyticBoxandPerformanceTrend}>
        <LineChart graphdata={graphdatametrics} />
      </Box>
      <br />
      <Box className={styles.AnalyticBoxandPerformanceTrend}>
        <LineChart graphDataOverall={graphdatametrics} />
      </Box>
    </Box>
  );
};

export default HomePage;
