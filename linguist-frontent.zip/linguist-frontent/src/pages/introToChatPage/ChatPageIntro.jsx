// eslint-disable-next-line no-unused-vars
import { Typography } from "@mui/material";

import { useNavigate } from "react-router-dom";
import img from "../../../public/linguist.jpg";

const ChatPageIntro = () => {
  const navigate = useNavigate();

  const handleChatPage = () => {
    navigate("/chatpage");
  };

  return (
    <div style={styles.container}>
      <div style={styles.introText}>
        <img src={img} width="40%" height="100%" style={{marginTop:"20px"}} />
        <h1>Welcome! I&apos;m your English Tutor, Linguist!</h1>
            <Typography fontFamily="poppins" fontSize="25px">
            I&apos;m here to guide you on your journey to mastering the English language.
            </Typography>
            <Typography fontFamily="poppins" fontSize="25px">
            Click the &quot;Start&quot; button to begin our conversation. Start by reading the paragraph. When you&apos;re ready, type &apos;Hi&apos; and enjoy the conversation. Whether you need help with grammar, speaking skills, or anything else related to English, I&apos;m here to assist you. Let&apos;s get started!
           </Typography>
        <button onClick={handleChatPage} style={styles.startButton}>
          Start
        </button>
      </div>
    </div>
  );
};
const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
    backgroundColor: "#FFFAFA",
  },
  introText: {
    textAlign: "center",
    maxWidth: "",
  },
  startButton: {
    marginTop: "20px",
    padding: "10px 30px",
    fontSize: "16px",
    cursor: "pointer",
    backgroundColor: "#5FB0FF",
    color: "white",
    border: "none",
    borderRadius: "25px",
  },
};

export default ChatPageIntro;
