import { useState } from "react";
import { TextField, Button, Alert, CircularProgress,Box } from "@mui/material";
import img from "../../../assets/linguist.jpg";
import { useNavigate } from "react-router-dom";
import styles from "./LoginPage.module.css";
import { loginDetails } from "../../services/moduleApi";

const LoginPage = () => {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handlename = (e) => setName(e.target.value);
  const handlepassword = (e) => setPassword(e.target.value);

  const handleKeyDown = (e) => {
         if (e.key === "Enter") {
         e.preventDefault();
          handleLoginForm(e);
        }
      };

  const handleLoginForm = async (e) => {
    e.preventDefault();
  
    if (!name || !password) {
      setErrorMessage("Username and Password are required");
      return;
    }
  
    setLoading(true);
    setErrorMessage("");
  
    try {
      const payload = { username: name, password: password };
      const jsonData = await loginDetails(payload);
  
      localStorage.setItem("token", jsonData.access_token);
      localStorage.setItem("refresh_token", jsonData.refresh_token);
      localStorage.setItem("username", name);
      localStorage.setItem("password", password);
  
      sessionStorage.setItem("user_id", jsonData.user_details.user_id);
      sessionStorage.setItem(
        "completed_paragraphs",
        JSON.stringify(jsonData.user_details.completed_paragraphs || [])
      );
  
      navigate("/homePage");
    } catch (error) {
      console.error("Login Error:", error.message);
      setErrorMessage(error?.message || "Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };
  


      
  return (
    <Box className={styles.mainCointer}>
      <Box className={styles.LoginBox}>
        <div className={styles.LoginImageBox}>
          <img width="100%" height="100%" src={img} alt="Login" />
          {/* <img width="100%" height="100%" src="./linguist.jpg" alt="Login" /> */}
        </div>
        <div className={styles.LoginInputBox}>
          <TextField
            id="outlined-basic"
            variant="outlined"
            placeholder="Enter UserName"
            type="text"
            value={name}
            onChange={handlename}
            onKeyDown={handleKeyDown}
            InputProps={{
              style: { backgroundColor: "white", borderRadius: "20px" },
            }}
          />
          <TextField
            id="outlined-basic"
            placeholder="Enter the Password"
            type="password"
            value={password}
            onChange={handlepassword}
            onKeyDown={handleKeyDown}
            variant="outlined"
            InputProps={{
              style: { backgroundColor: "white", borderRadius: "20px" },
            }}
          />
        </div>

        {errorMessage && (
          <Alert severity="error" sx={{ width: "80%", marginTop: "10px" }}>
            {errorMessage}
          </Alert>
        )}

        <Button
          variant="contained"
          sx={{ width: "80%", borderRadius: "20px", marginTop: "20px" }}
          size="large"
          onClick={handleLoginForm}
          type="submit"
          disabled={loading}
        >
          {loading ? <CircularProgress size={24} sx={{ color: "white" }} /> : "Login"}
        </Button>
      </Box>
    </Box>
  );
};

export default LoginPage;
