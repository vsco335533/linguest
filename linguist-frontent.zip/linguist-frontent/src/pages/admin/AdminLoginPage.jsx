import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { TextField, Button, Alert, CircularProgress, IconButton, InputAdornment } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import img from "../loginPage/linguist.jpg";
import { loginDetails } from "../../services/moduleApi";
import styles from "./AdminLoginPage.module.css";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", password: "" });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSubmit(e);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await loginDetails({ username: form.username, password: form.password });
      if (!data?.user_details?.is_admin) {
        setError("Access denied. Admin credentials required.");
        return;
      }
      window.localStorage.setItem("token", data.access_token);
      window.localStorage.setItem("refresh_token", data.refresh_token);
      window.localStorage.setItem("username", form.username);
      window.localStorage.setItem("admin_user_id", data.user_details.user_id);
      navigate("/admin/dashboard");
    } catch (err) {
      setError(err.message || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.mainContainer}>
      <div className={styles.loginBox}>
        <div className={styles.logoBox}>
          <img src={img} alt="Linguist" />
        </div>

        <span className={styles.adminBadge}>Admin Portal</span>

        <div className={styles.inputBox}>
          <TextField
            placeholder="Enter Username"
            type="text"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            onKeyDown={handleKeyDown}
            fullWidth
            InputProps={{ style: { backgroundColor: "white", borderRadius: "20px" } }}
          />
          <TextField
            placeholder="Enter Password"
            type={showPwd ? "text" : "password"}
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            onKeyDown={handleKeyDown}
            fullWidth
            InputProps={{
              style: { backgroundColor: "white", borderRadius: "20px" },
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowPwd(!showPwd)} edge="end">
                    {showPwd ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </div>

        {error && (
          <div className={styles.errorBox}>
            <Alert severity="error">{error}</Alert>
          </div>
        )}

        <Button
          className={styles.submitButton}
          variant="contained"
          size="large"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? <CircularProgress size={24} sx={{ color: "#2E8BC0" }} /> : "Login"}
        </Button>
      </div>
    </div>
  );
}
