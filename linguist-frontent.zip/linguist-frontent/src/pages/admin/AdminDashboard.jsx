/* eslint-disable react/prop-types */
import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  Typography, Tabs, Tab, Table, TableHead, TableBody, TableRow, TableCell,
  TableContainer, Paper, Button, IconButton, TextField, Dialog, DialogTitle,
  DialogContent, DialogActions, Avatar, Chip, CircularProgress, Alert,
  Snackbar, LinearProgress, Tooltip, InputAdornment
} from "@mui/material";
import {
  People, School, CheckCircle, BarChart, Add, Edit, Delete,
  Upload, Download, Logout, Refresh, Search, Close, MenuBook, ExpandMore, ExpandLess
} from "@mui/icons-material";
import { Bar, Line } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  LineElement, PointElement, Title, Tooltip as ChartTooltip, Legend
} from "chart.js";
import {
  adminGetOverview, adminGetUsers, adminCreateUser,
  adminBulkUpload, adminUpdateUser, adminDeleteUser,
  adminGetStudentPerformance,
  adminGetStories, adminCreateStory, adminUpdateStory, adminDeleteStory,
  adminBulkUploadStories,
  adminGetParagraphs, adminAddParagraph, adminUpdateParagraph, adminDeleteParagraph
} from "../../services/moduleApi";
import styles from "./AdminDashboard.module.css";

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, ChartTooltip, Legend);

const BLUE = "#5FB0FF";
const DARK_BLUE = "#2E8BC0";

const chartOpts = {
  responsive: true,
  plugins: { legend: { position: "top" } },
  scales: { y: { beginAtZero: true } },
};

// ── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ icon, label, value }) {
  return (
    <div className={styles.statCard}>
      <div className={styles.statIcon}>{icon}</div>
      <div>
        <div className={styles.statValue}>{value ?? "—"}</div>
        <div className={styles.statLabel}>{label}</div>
      </div>
    </div>
  );
}

// ── CEFR chip colour ─────────────────────────────────────────────────────────
const cefrColor = (level) => {
  if (!level || level === "Not Assessed") return "default";
  if (level.startsWith("A1")) return "warning";
  if (level.startsWith("A2")) return "info";
  return "success";
};

// ════════════════════════════════════════════════════════════════════════════
export default function AdminDashboard() {
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);
  const [snack, setSnack] = useState({ open: false, msg: "", severity: "success" });

  useEffect(() => {
    if (!window.localStorage.getItem("admin_user_id")) navigate("/admin/login");
  }, [navigate]);

  const notify = useCallback((msg, severity = "success") => setSnack({ open: true, msg, severity }), []);

  const handleLogout = () => {
    ["token", "refresh_token", "admin_user_id", "username"].forEach((k) => localStorage.removeItem(k));
    navigate("/admin/login");
  };

  return (
    <div className={styles.mainContainer}>
      {/* Header */}
      <div className={styles.header}>
        <Typography className={styles.headerTitle}>Linguist Admin</Typography>
        <div className={styles.headerRight}>
          <span className={styles.usernameText}>{localStorage.getItem("username")}</span>
          <Button className={styles.logoutBtn} startIcon={<Logout fontSize="small" />} onClick={handleLogout}>
            Logout
          </Button>
        </div>
      </div>

      {/* Tab bar */}
      <div className={styles.tabBar}>
        <Tabs
          value={tab}
          onChange={(_, v) => setTab(v)}
          sx={{
            px: 3,
            "& .MuiTab-root": { textTransform: "none", fontWeight: 600, color: "#888" },
            "& .Mui-selected": { color: DARK_BLUE },
            "& .MuiTabs-indicator": { backgroundColor: BLUE, height: 3, borderRadius: 2 },
          }}
        >
          <Tab label="Overview" icon={<BarChart fontSize="small" />} iconPosition="start" />
          <Tab label="Students" icon={<People fontSize="small" />} iconPosition="start" />
          <Tab label="Stories" icon={<MenuBook fontSize="small" />} iconPosition="start" />
          <Tab label="Performance" icon={<School fontSize="small" />} iconPosition="start" />
        </Tabs>
      </div>

      {/* Content */}
      <div className={styles.content}>
        {tab === 0 && <OverviewTab notify={notify} />}
        {tab === 1 && <StudentsTab notify={notify} />}
        {tab === 2 && <StoriesTab notify={notify} />}
        {tab === 3 && <PerformanceTab notify={notify} />}
      </div>

      <Snackbar
        open={snack.open}
        autoHideDuration={3500}
        onClose={() => setSnack({ ...snack, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnack({ ...snack, open: false })}
          severity={snack.severity}
          variant="filled"
          className={styles.infoAlert}
        >
          {snack.msg}
        </Alert>
      </Snackbar>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// Tab 1 — Overview
// ════════════════════════════════════════════════════════════════════════════
function OverviewTab({ notify }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await adminGetOverview();
      setData(res.data);
    } catch {
      notify("Failed to load overview", "error");
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => { load(); }, [load]);

  if (loading) return (
    <div style={{ display: "flex", justifyContent: "center", marginTop: 60 }}>
      <CircularProgress sx={{ color: BLUE }} />
    </div>
  );
  if (!data) return null;

  const { stats, cefr_distribution } = data;
  const cefrChart = {
    labels: cefr_distribution.map((d) => d.cefr_level),
    datasets: [{
      label: "Students",
      data: cefr_distribution.map((d) => d.count),
      backgroundColor: [BLUE, DARK_BLUE, "#93c5fd", "#bfdbfe", "#dbeafe"],
    }],
  };

  return (
    <div>
      <div className={styles.sectionHeader}>
        <span className={styles.sectionTitle}>Overview</span>
        <Button className={styles.btnOutlined} variant="outlined" startIcon={<Refresh />} size="small" onClick={load}>
          Refresh
        </Button>
      </div>

      <div className={styles.statCardsRow}>
        <StatCard icon={<People />}      label="Total Students"         value={stats.total_students} />
        <StatCard icon={<CheckCircle />} label="Students with Progress" value={stats.students_with_progress} />
        <StatCard icon={<School />}      label="Paragraphs Completed"   value={stats.total_completed_paragraphs} />
        <StatCard icon={<BarChart />}    label="Total Stories"          value={stats.total_stories} />
      </div>

      <div className={styles.card} style={{ maxWidth: 560 }}>
        <div className={styles.cardTitle}>CEFR Level Distribution</div>
        <Bar data={cefrChart} options={chartOpts} />
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// Tab 2 — Students
// ════════════════════════════════════════════════════════════════════════════
function StudentsTab({ notify }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [createDlg, setCreateDlg] = useState(false);
  const [editDlg, setEditDlg] = useState(null);
  const [deleteDlg, setDeleteDlg] = useState(null);
  const [bulkDlg, setBulkDlg] = useState(false);
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [csvFile, setCsvFile] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await adminGetUsers();
      setUsers(res.data || []);
    } catch {
      notify("Failed to load students", "error");
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => { load(); }, [load]);

  const filtered = users.filter((u) =>
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => { setForm({ username: "", email: "", password: "" }); setCreateDlg(true); };
  const openEdit = (u) => { setForm({ username: u.username, email: u.email, password: "" }); setEditDlg(u); };

  const handleCreate = async () => {
    setSaving(true);
    try {
      await adminCreateUser(form);
      notify("Student created");
      setCreateDlg(false);
      load();
    } catch (e) { notify(e.message || "Failed to create", "error"); }
    finally { setSaving(false); }
  };

  const handleEdit = async () => {
    setSaving(true);
    try {
      await adminUpdateUser(editDlg.id, form);
      notify("Student updated");
      setEditDlg(null);
      load();
    } catch (e) { notify(e.message || "Failed to update", "error"); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    setSaving(true);
    try {
      await adminDeleteUser(deleteDlg.id);
      notify("Student deleted");
      setDeleteDlg(null);
      load();
    } catch (e) { notify(e.message || "Failed to delete", "error"); }
    finally { setSaving(false); }
  };

  const handleBulkUpload = async () => {
    if (!csvFile) { notify("Select a CSV file first", "warning"); return; }
    setSaving(true);
    try {
      const res = await adminBulkUpload(csvFile);
      notify(`Created ${res.data?.created ?? 0} students, skipped ${res.data?.skipped ?? 0}`);
      setBulkDlg(false);
      setCsvFile(null);
      load();
    } catch (e) { notify(e.message || "Bulk upload failed", "error"); }
    finally { setSaving(false); }
  };

  const downloadTemplate = () => {
    const blob = new Blob(["username,email,password\nstudent_name,student@school.com,Pass@1234"], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "students_template.csv";
    a.click();
  };

  const dialogProps = { sx: { "& .MuiDialog-paper": { borderRadius: "20px" } }, disableScrollLock: true, disableRestoreFocus: true };
  const fieldSx = { "& .MuiOutlinedInput-root": { borderRadius: "12px" } };

  const FormFields = () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 8 }}>
      <TextField label="Username" fullWidth required value={form.username} sx={fieldSx}
        onChange={(e) => setForm({ ...form, username: e.target.value })} />
      <TextField label="Email" fullWidth required value={form.email} sx={fieldSx}
        onChange={(e) => setForm({ ...form, email: e.target.value })} />
      <TextField label="Password" fullWidth required={!editDlg} type="password" value={form.password} sx={fieldSx}
        onChange={(e) => setForm({ ...form, password: e.target.value })}
        helperText={editDlg ? "Leave blank to keep current password" : ""} />
    </div>
  );

  return (
    <div>
      <div className={styles.toolbar}>
        <TextField
          size="small"
          placeholder="Search students…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><Search fontSize="small" sx={{ color: "#aaa" }} /></InputAdornment> }}
          sx={{ flexGrow: 1, maxWidth: 360, "& .MuiOutlinedInput-root": { borderRadius: "20px" } }}
        />
        <div className={styles.toolbarActions}>
          <Button className={styles.btnOutlined} variant="outlined" startIcon={<Refresh />} size="small" onClick={load}>
            Refresh
          </Button>
          <Button className={styles.btnOutlined} variant="outlined" startIcon={<Upload />} size="small" onClick={() => setBulkDlg(true)}>
            Bulk Upload
          </Button>
          <Button className={styles.btnPrimary} variant="contained" startIcon={<Add />} size="small" onClick={openCreate}>
            Add Student
          </Button>
        </div>
      </div>

      {loading ? <LinearProgress sx={{ borderRadius: 4, bgcolor: "#EBF5FF", "& .MuiLinearProgress-bar": { bgcolor: BLUE } }} /> : (
        <TableContainer component={Paper} className={styles.tableContainer}>
          <Table size="small">
            <TableHead>
              <TableRow className={styles.tableHeadRow}>
                {["#", "Username", "Email", "CEFR Level", "Completed", "Last Active", "Actions"].map((h) => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: DARK_BLUE, bgcolor: "#EBF5FF" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ color: "#aaa", py: 4 }}>No students found</TableCell></TableRow>
              ) : filtered.map((u, i) => (
                <TableRow key={u.id} hover>
                  <TableCell>{i + 1}</TableCell>
                  <TableCell>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <Avatar sx={{ width: 28, height: 28, bgcolor: BLUE, fontSize: 12 }}>{u.username[0].toUpperCase()}</Avatar>
                      {u.username}
                    </div>
                  </TableCell>
                  <TableCell>{u.email}</TableCell>
                  <TableCell><Chip label={u.cefr_level} color={cefrColor(u.cefr_level)} size="small" /></TableCell>
                  <TableCell>{u.completed_paragraphs} paragraphs</TableCell>
                  <TableCell>{u.last_active ? new Date(u.last_active).toLocaleDateString() : "Never"}</TableCell>
                  <TableCell>
                    <Tooltip title="Edit">
                      <IconButton size="small" sx={{ color: BLUE }} onClick={() => openEdit(u)}><Edit fontSize="small" /></IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={() => setDeleteDlg(u)}><Delete fontSize="small" /></IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Create Dialog */}
      <Dialog open={createDlg} onClose={() => setCreateDlg(false)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Add Student</DialogTitle>
        <DialogContent><FormFields /></DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setCreateDlg(false)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleCreate} variant="contained" disabled={saving} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Create"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editDlg} onClose={() => setEditDlg(null)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Edit Student</DialogTitle>
        <DialogContent><FormFields /></DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setEditDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleEdit} variant="contained" disabled={saving} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Save"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={!!deleteDlg} onClose={() => setDeleteDlg(null)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: "#d32f2f", fontWeight: 700 }}>Delete Student</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete <strong>{deleteDlg?.username}</strong>? All their data will be removed.</Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleDelete} variant="contained" color="error" disabled={saving} sx={{ borderRadius: "20px", textTransform: "none" }}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Bulk Upload Dialog */}
      <Dialog open={bulkDlg} onClose={() => setBulkDlg(false)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ display: "flex", justifyContent: "space-between", color: DARK_BLUE, fontWeight: 700 }}>
          Bulk Upload Students
          <IconButton size="small" onClick={() => setBulkDlg(false)}><Close /></IconButton>
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" mb={2}>
            Upload a CSV with columns: <strong>username, email, password</strong>
          </Typography>
          <Button startIcon={<Download />} size="small" onClick={downloadTemplate}
            sx={{ mb: 2, color: BLUE, textTransform: "none", borderRadius: "20px" }}>
            Download Template
          </Button>
          <label style={{ display: "block", border: `2px dashed ${BLUE}`, borderRadius: 16, padding: 24, textAlign: "center", cursor: "pointer" }}>
            <input type="file" accept=".csv" hidden onChange={(e) => setCsvFile(e.target.files[0])} />
            {csvFile
              ? <Typography sx={{ color: BLUE, fontWeight: 600 }}>{csvFile.name}</Typography>
              : <Typography color="text.secondary">Click to select CSV file</Typography>}
          </label>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setBulkDlg(false)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleBulkUpload} variant="contained" disabled={saving || !csvFile} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Upload"}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// Tab 3 — Stories
// ════════════════════════════════════════════════════════════════════════════
const DIFFICULTY_LEVELS = ["Beginner", "Elementary", "Intermediate", "Upper-Intermediate", "Advanced", "Proficient"];
const LEVEL_TABS = ["All", ...DIFFICULTY_LEVELS];

function StoriesTab({ notify }) {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);
  const [paragraphs, setParagraphs] = useState({});
  const [paraLoading, setParaLoading] = useState(null);
  const [levelTab, setLevelTab] = useState("All"); // level filter

  // Story dialogs
  const [createDlg, setCreateDlg] = useState(false);
  const [editDlg, setEditDlg] = useState(null);
  const [deleteDlg, setDeleteDlg] = useState(null);
  const [storyForm, setStoryForm] = useState({ title: "", difficulty_level: "Beginner" });

  // Bulk upload dialog
  const [bulkDlg, setBulkDlg] = useState(false);
  const [csvFile, setCsvFile] = useState(null);

  // Paragraph dialogs
  const [addParaDlg, setAddParaDlg] = useState(null);
  const [editParaDlg, setEditParaDlg] = useState(null);
  const [deleteParaDlg, setDeleteParaDlg] = useState(null);
  const [paraForm, setParaForm] = useState({ content: "", paragraph_index: "" });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await adminGetStories(levelTab === "All" ? null : levelTab);
      setStories(res.data || []);
    } catch {
      notify("Failed to load stories", "error");
    } finally {
      setLoading(false);
    }
  }, [notify, levelTab]);

  useEffect(() => { load(); }, [load]);

  const toggleExpand = async (story) => {
    if (expanded === story.id) { setExpanded(null); return; }
    setExpanded(story.id);
    if (paragraphs[story.id]) return;
    setParaLoading(story.id);
    try {
      const res = await adminGetParagraphs(story.id);
      setParagraphs((p) => ({ ...p, [story.id]: res.data || [] }));
    } catch { notify("Failed to load paragraphs", "error"); }
    finally { setParaLoading(null); }
  };

  const reloadParagraphs = async (storyId) => {
    try {
      const res = await adminGetParagraphs(storyId);
      setParagraphs((p) => ({ ...p, [storyId]: res.data || [] }));
    } catch { notify("Failed to reload paragraphs", "error"); }
  };

  // Story CRUD
  const handleCreateStory = async () => {
    setSaving(true);
    try {
      await adminCreateStory(storyForm);
      notify("Story created");
      setCreateDlg(false);
      load();
    } catch (e) { notify(e.message || "Failed to create story", "error"); }
    finally { setSaving(false); }
  };

  const handleEditStory = async () => {
    setSaving(true);
    try {
      await adminUpdateStory(editDlg.id, storyForm);
      notify("Story updated");
      setEditDlg(null);
      load();
    } catch (e) { notify(e.message || "Failed to update story", "error"); }
    finally { setSaving(false); }
  };

  const handleDeleteStory = async () => {
    setSaving(true);
    try {
      await adminDeleteStory(deleteDlg.id);
      notify("Story deleted");
      setDeleteDlg(null);
      setExpanded(null);
      load();
    } catch (e) { notify(e.message || "Failed to delete story", "error"); }
    finally { setSaving(false); }
  };

  // Paragraph CRUD
  const handleAddParagraph = async () => {
    setSaving(true);
    try {
      await adminAddParagraph(addParaDlg.id, { content: paraForm.content, paragraph_index: parseInt(paraForm.paragraph_index) });
      notify("Paragraph added");
      setAddParaDlg(null);
      reloadParagraphs(addParaDlg.id);
      load();
    } catch (e) { notify(e.message || "Failed to add paragraph", "error"); }
    finally { setSaving(false); }
  };

  const handleEditParagraph = async () => {
    setSaving(true);
    try {
      await adminUpdateParagraph(editParaDlg.story.id, editParaDlg.para.id, {
        content: paraForm.content,
        paragraph_index: parseInt(paraForm.paragraph_index)
      });
      notify("Paragraph updated");
      reloadParagraphs(editParaDlg.story.id);
      setEditParaDlg(null);
    } catch (e) { notify(e.message || "Failed to update paragraph", "error"); }
    finally { setSaving(false); }
  };

  const handleDeleteParagraph = async () => {
    setSaving(true);
    try {
      await adminDeleteParagraph(deleteParaDlg.story.id, deleteParaDlg.para.id);
      notify("Paragraph deleted");
      reloadParagraphs(deleteParaDlg.story.id);
      load();
      setDeleteParaDlg(null);
    } catch (e) { notify(e.message || "Failed to delete paragraph", "error"); }
    finally { setSaving(false); }
  };

  const handleBulkUpload = async () => {
    if (!csvFile) return;
    setSaving(true);
    try {
      const fd = new FormData();
      fd.append("file", csvFile);
      const res = await adminBulkUploadStories(fd);
      notify(`Uploaded: ${res.data.created_stories} stories, ${res.data.created_paragraphs} paragraphs`);
      setBulkDlg(false);
      setCsvFile(null);
      load();
    } catch (e) { notify(e.message || "Bulk upload failed", "error"); }
    finally { setSaving(false); }
  };

  const openCreate = () => { setStoryForm({ title: "", difficulty_level: levelTab !== "All" ? levelTab : "Beginner" }); setCreateDlg(true); };
  const openEdit = (s) => { setStoryForm({ title: s.title, difficulty_level: s.difficulty_level }); setEditDlg(s); };
  const openAddPara = (s) => {
    const nextIdx = (paragraphs[s.id]?.length ?? 0) + 1;
    setParaForm({ content: "", paragraph_index: String(nextIdx) });
    setAddParaDlg(s);
  };
  const openEditPara = (story, para) => {
    setParaForm({ content: para.content, paragraph_index: String(para.paragraph_index) });
    setEditParaDlg({ story, para });
  };

  const dialogProps = { sx: { "& .MuiDialog-paper": { borderRadius: "20px" } }, disableScrollLock: true, disableRestoreFocus: true };
  const fieldSx = { "& .MuiOutlinedInput-root": { borderRadius: "12px" } };

  return (
    <div>
      <div className={styles.sectionHeader}>
        <span className={styles.sectionTitle}>Stories</span>
        <div style={{ display: "flex", gap: 8 }}>
          <Button className={styles.btnOutlined} variant="outlined" startIcon={<Refresh />} size="small" onClick={load}>Refresh</Button>
          <Button className={styles.btnOutlined} variant="outlined" startIcon={<Upload />} size="small" onClick={() => { setCsvFile(null); setBulkDlg(true); }}>Bulk Upload</Button>
          <Button className={styles.btnPrimary} variant="contained" startIcon={<Add />} size="small" onClick={openCreate}>Add Story</Button>
        </div>
      </div>

      {/* Level filter tabs */}
      <Tabs
        value={levelTab}
        onChange={(_, v) => { setLevelTab(v); setExpanded(null); }}
        variant="scrollable"
        scrollButtons="auto"
        sx={{
          mb: 2, borderBottom: "1px solid #EBF5FF",
          "& .MuiTab-root": { textTransform: "none", fontWeight: 600, fontSize: 13, color: "#888" },
          "& .Mui-selected": { color: DARK_BLUE },
          "& .MuiTabs-indicator": { backgroundColor: BLUE, height: 3, borderRadius: 2 },
        }}
      >
        {LEVEL_TABS.map((l) => <Tab key={l} label={l} value={l} />)}
      </Tabs>

      {loading ? (
        <LinearProgress sx={{ borderRadius: 4, bgcolor: "#EBF5FF", "& .MuiLinearProgress-bar": { bgcolor: BLUE } }} />
      ) : stories.length === 0 ? (
        <Alert severity="info" className={styles.infoAlert}>No stories yet. Click "Add Story" to create one.</Alert>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {stories.map((s) => (
            <Paper key={s.id} className={styles.card} style={{ margin: 0, padding: 0, overflow: "hidden" }}>
              {/* Story row */}
              <div style={{ display: "flex", alignItems: "center", padding: "14px 20px", gap: 12 }}>
                <Avatar sx={{ width: 36, height: 36, bgcolor: DARK_BLUE, fontSize: 14 }}>{s.id}</Avatar>
                <div style={{ flexGrow: 1 }}>
                  <Typography fontWeight={700}>{s.title}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {s.difficulty_level} &nbsp;·&nbsp; {s.paragraph_count} paragraph{s.paragraph_count !== 1 ? "s" : ""}
                  </Typography>
                </div>
                <Tooltip title="Add paragraph">
                  <IconButton size="small" sx={{ color: BLUE }} onClick={() => openAddPara(s)}><Add fontSize="small" /></IconButton>
                </Tooltip>
                <Tooltip title="Edit story">
                  <IconButton size="small" sx={{ color: BLUE }} onClick={() => openEdit(s)}><Edit fontSize="small" /></IconButton>
                </Tooltip>
                <Tooltip title="Delete story">
                  <IconButton size="small" color="error" onClick={() => setDeleteDlg(s)}><Delete fontSize="small" /></IconButton>
                </Tooltip>
                <Tooltip title={expanded === s.id ? "Collapse" : "Show paragraphs"}>
                  <IconButton size="small" sx={{ color: "#888" }} onClick={() => toggleExpand(s)}>
                    {expanded === s.id ? <ExpandLess /> : <ExpandMore />}
                  </IconButton>
                </Tooltip>
              </div>

              {/* Paragraphs panel */}
              {expanded === s.id && (
                <div style={{ borderTop: "1px solid #EBF5FF", background: "#f9fbff" }}>
                  {paraLoading === s.id ? (
                    <LinearProgress sx={{ borderRadius: 0, bgcolor: "#EBF5FF", "& .MuiLinearProgress-bar": { bgcolor: BLUE } }} />
                  ) : (
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          {["#", "Content", "Actions"].map((h) => (
                            <TableCell key={h} sx={{ fontWeight: 700, color: DARK_BLUE, bgcolor: "#EBF5FF", fontSize: 12 }}>{h}</TableCell>
                          ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {(paragraphs[s.id] || []).length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={3} align="center" sx={{ color: "#aaa", py: 2, fontSize: 13 }}>
                              No paragraphs yet — click the + icon to add one.
                            </TableCell>
                          </TableRow>
                        ) : (paragraphs[s.id] || []).map((p) => (
                          <TableRow key={p.id} hover>
                            <TableCell sx={{ width: 40, fontWeight: 600, color: DARK_BLUE }}>{p.paragraph_index}</TableCell>
                            <TableCell sx={{ maxWidth: 480 }}>
                              <Typography variant="body2" sx={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                                {p.content.length > 200 ? p.content.slice(0, 200) + "…" : p.content}
                              </Typography>
                            </TableCell>
                            <TableCell sx={{ width: 88 }}>
                              <Tooltip title="Edit">
                                <IconButton size="small" sx={{ color: BLUE }} onClick={() => openEditPara(s, p)}><Edit fontSize="small" /></IconButton>
                              </Tooltip>
                              <Tooltip title="Delete">
                                <IconButton size="small" color="error" onClick={() => setDeleteParaDlg({ story: s, para: p })}><Delete fontSize="small" /></IconButton>
                              </Tooltip>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </div>
              )}
            </Paper>
          ))}
        </div>
      )}

      {/* Create Story */}
      <Dialog open={createDlg} onClose={() => setCreateDlg(false)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Add Story</DialogTitle>
        <DialogContent>
          <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 8 }}>
            <TextField label="Title" fullWidth required value={storyForm.title} sx={fieldSx}
              onChange={(e) => setStoryForm({ ...storyForm, title: e.target.value })} />
            <TextField label="Difficulty Level" select fullWidth required value={storyForm.difficulty_level} sx={fieldSx}
              onChange={(e) => setStoryForm({ ...storyForm, difficulty_level: e.target.value })}
              SelectProps={{ native: true }}>
              {DIFFICULTY_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </TextField>
          </div>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setCreateDlg(false)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleCreateStory} variant="contained" disabled={saving} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Create"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Story */}
      <Dialog open={!!editDlg} onClose={() => setEditDlg(null)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Edit Story</DialogTitle>
        <DialogContent>
          <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 8 }}>
            <TextField label="Title" fullWidth required value={storyForm.title} sx={fieldSx}
              onChange={(e) => setStoryForm({ ...storyForm, title: e.target.value })} />
            <TextField label="Difficulty Level" select fullWidth required value={storyForm.difficulty_level} sx={fieldSx}
              onChange={(e) => setStoryForm({ ...storyForm, difficulty_level: e.target.value })}
              SelectProps={{ native: true }}>
              {DIFFICULTY_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </TextField>
          </div>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setEditDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleEditStory} variant="contained" disabled={saving} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Save"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Story */}
      <Dialog open={!!deleteDlg} onClose={() => setDeleteDlg(null)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: "#d32f2f", fontWeight: 700 }}>Delete Story</DialogTitle>
        <DialogContent>
          <Typography>Delete <strong>{deleteDlg?.title}</strong>? All paragraphs and student progress for this story will be permanently removed.</Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleDeleteStory} variant="contained" color="error" disabled={saving} sx={{ borderRadius: "20px", textTransform: "none" }}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Paragraph */}
      <Dialog open={!!addParaDlg} onClose={() => setAddParaDlg(null)} maxWidth="sm" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Add Paragraph — {addParaDlg?.title}</DialogTitle>
        <DialogContent>
          <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 8 }}>
            <TextField label="Paragraph Index" type="number" fullWidth required value={paraForm.paragraph_index} sx={fieldSx}
              onChange={(e) => setParaForm({ ...paraForm, paragraph_index: e.target.value })}
              helperText="Order within the story (1, 2, 3 …)" />
            <TextField label="Content" fullWidth required multiline minRows={6} value={paraForm.content} sx={fieldSx}
              onChange={(e) => setParaForm({ ...paraForm, content: e.target.value })} />
          </div>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setAddParaDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleAddParagraph} variant="contained" disabled={saving} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Add"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Paragraph */}
      <Dialog open={!!editParaDlg} onClose={() => setEditParaDlg(null)} maxWidth="sm" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Edit Paragraph</DialogTitle>
        <DialogContent>
          <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 8 }}>
            <TextField label="Paragraph Index" type="number" fullWidth required value={paraForm.paragraph_index} sx={fieldSx}
              onChange={(e) => setParaForm({ ...paraForm, paragraph_index: e.target.value })} />
            <TextField label="Content" fullWidth required multiline minRows={6} value={paraForm.content} sx={fieldSx}
              onChange={(e) => setParaForm({ ...paraForm, content: e.target.value })} />
          </div>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setEditParaDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleEditParagraph} variant="contained" disabled={saving} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Save"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Paragraph */}
      <Dialog open={!!deleteParaDlg} onClose={() => setDeleteParaDlg(null)} maxWidth="xs" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: "#d32f2f", fontWeight: 700 }}>Delete Paragraph</DialogTitle>
        <DialogContent>
          <Typography>Delete paragraph #{deleteParaDlg?.para?.paragraph_index} from <strong>{deleteParaDlg?.story?.title}</strong>?</Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteParaDlg(null)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleDeleteParagraph} variant="contained" color="error" disabled={saving} sx={{ borderRadius: "20px", textTransform: "none" }}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Bulk Upload Stories */}
      <Dialog open={bulkDlg} onClose={() => setBulkDlg(false)} maxWidth="sm" fullWidth {...dialogProps}>
        <DialogTitle sx={{ color: DARK_BLUE, fontWeight: 700 }}>Bulk Upload Stories</DialogTitle>
        <DialogContent>
          <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 8 }}>
            <Alert severity="info" sx={{ borderRadius: "12px" }}>
              Upload a CSV file with columns: <strong>title, difficulty_level, content</strong>.<br />
              Each row is one paragraph. Rows sharing the same title &amp; level are grouped into one story.<br />
              Valid levels: {DIFFICULTY_LEVELS.join(", ")}.
            </Alert>
            <Button
              variant="outlined"
              component="label"
              startIcon={<Upload />}
              sx={{ borderRadius: "12px", textTransform: "none", borderColor: BLUE, color: BLUE }}
            >
              {csvFile ? csvFile.name : "Choose CSV file"}
              <input type="file" accept=".csv" hidden onChange={(e) => setCsvFile(e.target.files[0] || null)} />
            </Button>
            {csvFile && (
              <Typography variant="body2" color="text.secondary">
                Selected: {csvFile.name} ({(csvFile.size / 1024).toFixed(1)} KB)
              </Typography>
            )}
          </div>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setBulkDlg(false)} sx={{ borderRadius: "20px", textTransform: "none" }}>Cancel</Button>
          <Button onClick={handleBulkUpload} variant="contained" disabled={saving || !csvFile} className={styles.btnPrimary}>
            {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Upload"}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// Tab 4 — Performance
// ════════════════════════════════════════════════════════════════════════════
function PerformanceTab({ notify }) {
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [perfData, setPerfData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    adminGetUsers()
      .then((r) => setUsers(r.data || []))
      .catch(() => notify("Failed to load students", "error"));
  }, [notify]);

  const loadPerf = async (user) => {
    setSelected(user);
    setLoading(true);
    try {
      const res = await adminGetStudentPerformance(user.id);
      setPerfData(res.data);
    } catch { notify("Failed to load performance", "error"); }
    finally { setLoading(false); }
  };

  const buildChart = (perf, label, key, color) => ({
    labels: perf.map((_, i) => `Attempt ${i + 1}`),
    datasets: [{
      label,
      data: perf.map((p) => p[key] ?? 0),
      borderColor: color,
      backgroundColor: color + "33",
      tension: 0.3,
      fill: true,
    }],
  });

  return (
    <div>
      <Typography className={styles.sectionTitle} sx={{ mb: 2 }}>Student Performance</Typography>

      {/* Student selector chips */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>
        {users.map((u) => (
          <Chip
            key={u.id}
            label={u.username}
            onClick={() => loadPerf(u)}
            clickable
            variant={selected?.id === u.id ? "filled" : "outlined"}
            sx={selected?.id === u.id
              ? { bgcolor: BLUE, color: "#fff", fontWeight: 600, borderColor: BLUE }
              : { borderColor: BLUE, color: BLUE }}
          />
        ))}
      </div>

      {loading && (
        <LinearProgress sx={{ mb: 2, borderRadius: 4, bgcolor: "#EBF5FF", "& .MuiLinearProgress-bar": { bgcolor: BLUE } }} />
      )}

      {perfData && !loading && (
        <div>
          {/* Student info card */}
          <div className={styles.card}>
            <div style={{ display: "flex", gap: 20, alignItems: "center", flexWrap: "wrap" }}>
              <Avatar sx={{ width: 56, height: 56, bgcolor: BLUE, fontSize: 22 }}>
                {perfData.user.username[0].toUpperCase()}
              </Avatar>
              <div>
                <Typography variant="h6" fontWeight={700}>{perfData.user.username}</Typography>
                <Typography variant="body2" color="text.secondary">{perfData.user.email}</Typography>
              </div>
              <Chip label={perfData.user.cefr_level} color={cefrColor(perfData.user.cefr_level)} sx={{ ml: 1 }} />
              <div style={{ marginLeft: "auto", textAlign: "right" }}>
                <Typography variant="h5" fontWeight={700} sx={{ color: BLUE }}>{perfData.performance.length}</Typography>
                <Typography variant="body2" color="text.secondary">Attempts</Typography>
              </div>
            </div>
          </div>

          {/* Story progress */}
          {perfData.story_progress.length > 0 && (
            <div className={styles.card}>
              <div className={styles.cardTitle}>Story Progress</div>
              {perfData.story_progress.map((s) => (
                <div key={s.story_id} style={{ marginBottom: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <Typography variant="body2">{s.title}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {s.completed_paragraphs}/{s.total_paragraphs} paragraphs
                    </Typography>
                  </div>
                  <LinearProgress
                    variant="determinate"
                    value={s.total_paragraphs ? (s.completed_paragraphs / s.total_paragraphs) * 100 : 0}
                    sx={{ height: 8, borderRadius: 4, bgcolor: "#EBF5FF", "& .MuiLinearProgress-bar": { bgcolor: BLUE } }}
                  />
                </div>
              ))}
            </div>
          )}

          {/* Charts */}
          {perfData.performance.length > 0 ? (
            <div className={styles.chartsGrid}>
              {[
                { label: "Overall Efficiency",  key: "overall_efficiency",       color: BLUE },
                { label: "Grammar Error %",      key: "grammar_error_percentage", color: "#ef4444" },
                { label: "Complexity %",         key: "complexity_percentage",    color: DARK_BLUE },
                { label: "Politeness %",         key: "politeness_percentage",    color: "#10b981" },
              ].map(({ label, key, color }) => (
                <div key={key} className={styles.card} style={{ marginBottom: 0 }}>
                  <div className={styles.cardTitle} style={{ fontSize: 15 }}>{label}</div>
                  <Line
                    data={buildChart(perfData.performance, label, key, color)}
                    options={{ ...chartOpts, plugins: { legend: { display: false } } }}
                  />
                </div>
              ))}
            </div>
          ) : (
            <Alert severity="info" className={styles.infoAlert}>No performance data yet for this student.</Alert>
          )}
        </div>
      )}

      {!selected && !loading && (
        <Alert severity="info" className={styles.infoAlert}>Select a student above to view their performance.</Alert>
      )}
    </div>
  );
}
