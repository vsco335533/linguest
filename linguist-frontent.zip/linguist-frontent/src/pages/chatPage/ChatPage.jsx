/* eslint-disable no-unused-vars */
import { useState, useRef, useEffect } from "react";
import "./scrollbar.css";
import {
  TextField,
  InputAdornment,
  IconButton,
  Box,
  Typography,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import AccountCircle from "@mui/icons-material/AccountCircle";
import StreamingText from "./StreamingTest";
import AudioRecorder from "./AudioRecorder";
import Timer from "./Timer";
import { Avatar } from "@mui/material";
import linguist from "../../../assets/favicon.ico";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import { TypeAnimation } from "react-type-animation";
import styles from "./ChatPage.module.css";
import {
  fetchParagraphDetails,
  fetchChatResponseStream,
  generateAudio,
  stopAudio,
} from "../../services/moduleApi";

function ChatPage() {
  const [aimessage, setAIMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const messagesEndRef = useRef(null);
  const [messageCount, setMessageCount] = useState(1);
  const [recording, setRecording] = useState(false);
  const [transcription, setTranscrption] = useState("");
  const [aiMessageCount, setAIMessageCount] = useState(0);
  const [paragraphIndex, setParagraphIndex] = useState(0);
  const [isRecordingReady, setIsRecordingReady] = useState(false);
  const [disable, setDisable] = useState(false);
  const [disableinput, setDisableInput] = useState(false);
  const [storiesdata, setStoriesData] = useState([]);
  const [paragrapharray, setParagraphArray] = useState([]);
  const [sessionstart, setSessionStart] = useState(true);
  const [paragraphCount, setParagraphCount] = useState(0);
  const [chatParagraphId, setChatParagraphId] = useState(null);
  const [content, setContent] = useState(null);
  const [chatParagraph, setChatParagraph] = useState(null);
  const [firstResponseReceived, setFirstResponseReceived] = useState(false);
  const [globalParagraphId, setGlobalParagraphID] = useState(1);
  const [newParagraphId, setNewParagraphId] = useState(null);
  const [isRecordingStop, setIsRecordingStop] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  useEffect(() => {
    // console.log(disable,"disable");
  }, [disable]);

  const handleHomePage = () => {
    stopAudio();
    navigate("/HomePage");
  };

  useEffect(() => {
    const handleBeforeUnload = () => stopAudio();

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);

  const fetchStoryParagraphs = async () => {
    try {
      const data = await fetchParagraphDetails(1);
      if (data && Array.isArray(data.data) && data.data.length > 0) {
        // console.log(data.data[0].content, "paragta");
        const paragraphId = data.data[0]?.paragraph_id;
        setContent(data.data[0].content);
        setStoriesData(data.data);
        setParagraphArray(data.data);
        setParagraphIndex(paragraphId);
        // console.log(paragraphId, "pid1")
        setNewParagraphId(paragraphId);
      }
    } catch (error) {
      console.error("Error fetching paragraph details:", error);
    }
  };

  useEffect(() => {
    fetchStoryParagraphs();
  }, []);

  const createIncrementalArray = (initialArray) => {
    let array = [...initialArray];
    return () => {
      array.push(array.length + 1);
      return [...array];
    };
  };

  useEffect(() => {
    if (messageCount % 16 === 0 && messageCount > 0) {
      // setParagraphIndex((prevIndex) => prevIndex + 1);

      let completedParagraphArray = JSON.parse(
        window.sessionStorage.getItem("completed_paragraphs") || "[]"
      );
      let incrementArrayFunc = createIncrementalArray(completedParagraphArray);
      let updatedArray = incrementArrayFunc();

      window.sessionStorage.setItem(
        "completed_paragraphs",
        JSON.stringify(updatedArray)
      );
    }
  }, [messageCount]);

  useEffect(() => {
    if (messages.length % 2 == 0 && messages.length > 0) {
      setDisableInput(true);
    }
    // console.log(messages.length);
    // console.log(messages);
  }, [messages]);

  const handleSend = async () => {
    if (isSending) return;
    if (aimessage.trim() || messageCount % 2 === 0) {
      setIsSending(true);
      const newMessage = {
        text: aimessage,
        sender: "user",
        improvement: "waiting",
      };
      const loadingmessage = {
        text: aimessage,
        sender: "bot",
        improvement: "Typing",
      };

      setMessages((prevMessages) => [
        ...prevMessages,
        newMessage,
        loadingmessage,
      ]);
      setAIMessage("");
      setMessageCount((prevCount) => prevCount + 1);

      if ((messageCount + 1) % 15 === 0) {
        // setParagraphIndex((prevIndex) => prevIndex + 1);

        let completedParagraphs = JSON.parse(
          window.sessionStorage.getItem("completed_paragraphs") || "[]"
        );
        completedParagraphs.push(paragraphIndex + 1);
        window.sessionStorage.setItem(
          "completed_paragraphs",
          JSON.stringify(completedParagraphs)
        );

        fetchParagraphDetails(paragraphIndex + 1).then((data) => {
          if (data) {
            setParagraphArray(data.data);
          }

          console.log(data.data, "Paragra");
        });
      }
      console.log(newParagraphId, "pI");

      try {
        console.log(newParagraphId, "paragraphid");
        const payload = {
          user_id: parseInt(window.sessionStorage.getItem("user_id"), 10),
          user_input: newMessage.text,
          selected_level: window.sessionStorage.getItem("cefrrating") || "A1: Beginner",
          paragraph_id: newParagraphId,
          is_new_session: sessionstart,
          global_interaction_id: globalParagraphId,
        };

        // Add an empty streaming bot message (will be filled token by token)
        const streamingId = Date.now();
        setMessages((prev) => prev.filter((m) => m.improvement !== "Typing"));
        setMessages((prev) => [...prev, { id: streamingId, text: "", sender: "bot", improvement: "streaming" }]);

        let accumulated = "";

        await fetchChatResponseStream(
          payload,
          // onToken — append each arriving chunk
          (token) => {
            accumulated += token;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === streamingId ? { ...m, text: accumulated } : m
              )
            );
          },
          // onDone — store metadata, finalise message
          (meta) => {
            setContent(meta.paragraph);
            setGlobalParagraphID(meta.global_interaction_id);
            setNewParagraphId(meta.paragraph_id);
            setDisableInput(false);
            setSessionStart(false);
            setDisable(false);
            setAIMessageCount((prevCount) => prevCount + 1);
            setMessages((prev) =>
              prev.map((m) =>
                m.id === streamingId
                  ? { ...m, text: meta.output, improvement: "" }
                  : m
              )
            );
            // Fix improvement indicator on preceding user message
            setMessages((prev) => {
              const updated = [...prev];
              let userIdx = -1;
              for (let i = updated.length - 1; i >= 0; i--) {
                if (updated[i].sender === "user" && updated[i].improvement === "waiting") { userIdx = i; break; }
              }
              if (userIdx !== -1) updated[userIdx] = { ...updated[userIdx], improvement: meta.improvement };
              return updated;
            });
            generateAudio(meta.output);
          }
        );
      } catch (error) {
        console.error("Error fetching response:", error);
        const errorText = error instanceof TypeError
          ? "Network connection lost. Please check your connection and try again."
          : "Sorry, something went wrong. Please try again.";
        setMessages((prevMessages) => [
          ...prevMessages,
          { text: errorText, sender: "bot" },
        ]);
        setDisableInput(false);
      } finally {
        setIsSending(false);
      }
    }
  };

  useEffect(() => {
    if (transcription % 2 !== 0) {
      setAIMessage(transcription);
      // console.log(disable);
      setDisable(true);
      setIsRecordingReady(true);
      // console.log(transcription);
    }
  }, [transcription]);

  const handleTranscriptionUpdate = (newTranscription) => {
    setTranscrption(newTranscription);
    if (newTranscription.trim()) {
      setIsRecordingReady(true);
    }
  };

  const handleRecordingStop = (stopped) => {
    setIsRecordingReady(stopped);
  };

  return (
    <Box className={styles.mainContainer}>
      <Box className={styles.headerBox}>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="profile"
          onClick={handleHomePage}
          style={{ marginLeft: "20px" }}
        >
          <ArrowBackIcon style={{ fontSize: 40, color: "#6D7D8B" }} />
        </IconButton>

        <IconButton edge="start" color="inherit" aria-label="profile">
          {window.sessionStorage.getItem("cefrrating") ? (
            <div className={styles.ProfileIcon}>
              <h5>
                {window.sessionStorage.getItem("cefrrating").charAt(0) +
                  window.sessionStorage.getItem("cefrrating").charAt(1)}
              </h5>
            </div>
          ) : (
            <AccountCircle style={{ fontSize: 70, color: "#5FB0FF" }} />
          )}
        </IconButton>
      </Box>
      <Box className={styles.ParagraphBox}>
        {paragrapharray.length > 0 &&
          paragraphCount < paragrapharray.length && (
            <div className="custom_scrollbar">
              <Typography
                className={styles.ParagraphTypographStyles}
                style={{
                  fontSize: "23px",
                  fontFamily: "poppins",
                  fontWeight: "500",
                  textAlign: "justify",
                }}
              >
          

                {firstResponseReceived
                  ? chatParagraph || "Loading ..."
                  : content || "Loading..."}
              </Typography>
            </div>
          )}
      </Box>
      <Box
        width="100%"
        height="50%"
        className="custom_scrollbar"
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-start",
          flexGrow: 1,
          overflowY: "auto",
          padding: "10px 0 20px 0",
        }}
      >
        {messages.map((msg, index) => (
          <Box
            key={index}
            display="flex"
            justifyContent={msg.sender === "user" ? "flex-end" : "flex-start"}
            marginBottom={2}
          >
            <Box
              style={{
                backgroundColor: msg.sender === "user" ? "#8FA8FF" : "#DEF1F9",
                color: "#000000",
                padding: "10px 10px 10px 15px",
                borderRadius:
                  msg.sender === "user"
                    ? "20px 20px 0px 20px"
                    : "20px 20px 20px 0px",
                maxWidth: "70%",
                whiteSpace: "normal",
                position: "relative",
                marginLeft: msg.sender === "bot" ? "35px" : "0",
                marginRight: msg.sender === "user" ? "35px" : "0",
              }}
            >
              <Typography
                component="div"
                variant="body1"
                style={{
                  fontSize: "23px",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: "500",
                }}
              >
                {msg.sender === "bot" ? (
                  msg.improvement === "Typing" ? (
                    <TypingIndicator />
                  ) : (
                    <StreamingText text={msg.text} />
                  )
                ) : (
                  msg.text
                )}
              </Typography>

              <Avatar
                style={{
                  position: "absolute",
                  bottom: "-25px",
                  right: msg.sender === "user" ? "-25px" : "auto",
                  left: msg.sender === "bot" ? "-25px" : "auto",
                  width: "38px",
                  height: "38px",
                  backgroundColor:
                    msg.sender === "user" ? "#8FA8FF" : "#DEF1F9",
                  boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.2)",
                  overflow: "hidden",
                }}
              >
                {msg.sender === "user" ? (
                  msg.improvement === "Red" ? (
                    <ArrowDownwardIcon
                      className={styles.ArrowIcon}
                      style={{
                        backgroundColor: "red",
                      }}
                    />
                  ) : (
                    <ArrowUpwardIcon
                      className={styles.ArrowIcon}
                      style={{
                        backgroundColor: "green",
                      }}
                    />
                  )
                ) : (
                  <img
                    src={linguist}
                    alt="Bot Icon"
                    style={{
                      width: "50px",
                      height: "50px",
                      objectFit: "fill",
                    }}
                  />
                )}
              </Avatar>
            </Box>
          </Box>
        ))}
        <div ref={messagesEndRef} />
      </Box>
      <Box display="flex" alignItems="center" justifyContent="center">
        {messageCount % 2 === 0 && recording && <Timer />}
        {messageCount % 2 !== 0   ? (
          <TextField
            className={styles.TextBox}
            variant="outlined"
            placeholder="Type Hi..."
            value={aimessage}
            onChange={(e) => setAIMessage(e.target.value)}
            onKeyUp={(e) => e.key === "Enter" && handleSend()}
            disabled={isSending}
            multiline={false}
            autoComplete="off"
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment className={styles.inputAdornment}>
                    <IconButton edge="end" onClick={handleSend} disabled={isSending}>
                      <SendIcon className={styles.sendIconButton} style={{ color: isSending ? "#ccc" : undefined }} />
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }}
            sx={{
              "& .MuiOutlinedInput-root": {
                borderRadius: "30px",
                backgroundColor: "#f3f3f3",
                marginBottom: "25px",
              },
            }}
          />
        ) : (
          <Box
            width="100%"
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            {disableinput && (
              <TextField
                fullWidth={false}
                variant="outlined"
                value={aimessage}
                onChange={(e) => setAIMessage(e.target.value)}
                onKeyUp={(e) => e.key === "Enter" && handleSend()}
                disabled={true}
                slotProps={{
                  input: {
                    style: {
                      fontSize: "1.85rem",
                      overflow: "hidden",
                      color: "transparent",
                    },
                    endAdornment: (
                      <InputAdornment>
                        <Box styles={{ opacity: 0, color: "transparent" }}>
                          {messageCount % 2 === 0 && (
                            <>
                              <AudioRecorder
                                onTranscriptionUpdate={
                                  handleTranscriptionUpdate
                                }
                                onRecordingStop={handleRecordingStop}
                              />
                            </>
                          )}
                        </Box>
                        {disable && isRecordingReady && (
                          <>
                            <IconButton
                              edge="end"
                              onKeyUp={(e) => e.key === "Enter" && handleSend()}
                              onClick={handleSend}
                              disabled={!disable && !transcription}
                            >
                              <SendIcon
                                style={{
                                  fontSize: 40,
                                  color: "#008CBA",
                                  paddingRight: "20px",
                                }}
                              />
                            </IconButton>
                          </>
                        )}
                        {/* {isRecordingStop && disable && (
                          <IconButton edge="end"
                          onKeyUp={(e) => e.key === "Enter" && handleSend()}
                          onClick={handleSend}
                         disabled={!disable && !transcription}
                         >
                            <SendIcon  style={{
                                  fontSize: 40,
                                  color: "#008CBA",
                                  paddingRight: "20px",
                                }} />
                          </IconButton>
                        )} */}
                      </InputAdornment>
                    ),
                  },
                }}
                sx={{
                  width: "256px",
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                    backgroundColor: "#e6e6e6",
                    marginBottom: "25px",
                    "& fieldset": {
                      borderColor: "#aaa",
                    },
                    "&:hover fieldset": {
                      borderColor: "#777",
                    },
                  },
                }}
              />
            )}
          </Box>
        )}
      </Box>
    </Box>
  );
}
const TypingIndicator = () => {
  return (
    <TypeAnimation
      sequence={["Linguist is typing...", 1000, "", 500]}
      wrapper="span"
      speed={50}
      style={{ fontSize: "1em", display: "inline-block" }}
      repeat={Infinity}
    />
  );
};
export default ChatPage;
