
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useState, useEffect, useRef } from "react";
import { Box, IconButton } from "@mui/material";
import MicIcon from "@mui/icons-material/Mic";
import MicOffIcon from "@mui/icons-material/MicOff";
import Timer from "./Timer";
import { PulseLoader } from "react-spinners";

const AudioRecorder = ({ onTranscriptionUpdate,onRecordingStop }) => {
  const [recording, setRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);
  const recognitionRef = useRef(null);
  const [text, setText] = useState("");
  const finalTranscriptRef = useRef("");

  useEffect(() => {
    if ("SpeechRecognition" in window || "webkitSpeechRecognition" in window) {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = "en-US";

      recognitionRef.current.onresult = (event) => {
        let interimTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscriptRef.current += event.results[i][0].transcript + " ";
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        const fullTranscript = finalTranscriptRef.current + interimTranscript;
        if (fullTranscript.trim()) {
          setText(fullTranscript);
          onTranscriptionUpdate(fullTranscript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        if (event.error === "not-allowed") {
          setError("Microphone access denied. Please allow microphone permission in your browser settings and reload.");
        } else if (event.error === "network") {
          setError("Network error. Speech recognition requires an internet connection.");
        } else if (event.error === "no-speech") {
          setError("No speech detected. Please speak clearly and try again.");
        } else {
          setError("Speech recognition error: " + event.error);
        }
        setRecording(false);
      };
    } else {
      console.log("Speech recognition is not supported in this browser.");
      setError("Speech recognition is not supported in this browser.");
    }
  }, []);

  const handleMicClick = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (recording) {
      recognitionRef.current.stop();
      setRecording(false);
      onRecordingStop(true);
      onTranscriptionUpdate(text); 
    } else {
      finalTranscriptRef.current = "";
      setText("");
      recognitionRef.current.abort();
      recognitionRef.current.start();
      setRecording(true);
      onRecordingStop(false)
    }
  };

  return (
    <div>
      <Box display="flex" alignItems="center" gap="12px">
        <Box>
          <Timer isRunning={recording} />
        </Box>

        <Box>
          <IconButton onClick={handleMicClick} disabled={loading}>
            {recording ? (
              <MicIcon style={{ color: "green", fontSize: 40 }} />
            ) : (
              <MicOffIcon style={{ color: "red", fontSize: 40 }} />
            )}
          </IconButton>
        </Box>

        <Box>{processing && <PulseLoader size={10} color="#008CBA" />}</Box>
      </Box>

      {error && <p style={{ color: "red" }}>Error: {error}</p>}
    </div>
  );
};

export default AudioRecorder;



