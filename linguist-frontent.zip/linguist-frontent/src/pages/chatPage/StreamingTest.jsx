/* eslint-disable react/prop-types */
import  { useState, useEffect } from 'react';

const StreamingText = ({ text }) => {
  // console.log(text)
  const words = text.split(' '); 
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (currentIndex < words.length) {
      const timeout = setTimeout(() => {
        setCurrentIndex((prevIndex) => prevIndex + 1);
      }, 450); 

      return () => clearTimeout(timeout);
    }
  }, [currentIndex, words.length]);

  return (
    <div style={{ 
      display: 'flex',
      flexWrap: 'wrap',         
      gap: '5px',
      overflow: 'hidden',      
      maxWidth: '100%',         
      whiteSpace: 'normal',     
      fontSize: '23px',         
      fontFamily: 'Poppins, sans-serif', 
      fontWeight: '500',
      textAlign: 'justify'
     }}>
      {words.map((word, index) => (
        <span
          key={index}
          style={{
            color: index <= currentIndex ? 'black' : '#DEF1F9', 
            transition: 'color 3s ease',
            opacity: index <= currentIndex ? 1 : 0.3, 
          }}
        >
          {word}
        </span>
      ))}
    </div>
  );
};

export default StreamingText;






