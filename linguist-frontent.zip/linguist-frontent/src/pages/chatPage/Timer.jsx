/* eslint-disable react/prop-types */
import  { useState, useEffect } from 'react';
import './Timer.css';                     
const Timer = ({ isRunning }) => {
  const [seconds, setSeconds] = useState(0);
  const [minutes, setMinutes] = useState(0);

  useEffect(() => {
    let timer;
    if (isRunning) {
      timer = setInterval(() => {
        setSeconds((prevSeconds) => {
          if (prevSeconds === 59) {
            setMinutes((prevMinutes) => prevMinutes + 1);
            return 0;
          }
          return prevSeconds + 1;
        });
      }, 1000);
    } else {
      clearInterval(timer);
      // setSeconds(0);
      // setMinutes(0);
    }

    return () => clearInterval(timer);
  }, [isRunning]);
  return (
    <div className="timer-container">
      <span className="blinking-dot"></span>
      {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}

    </div>
  );
};

export default Timer;




