/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
/* eslint-disable no-useless-catch */

import axiosInstance from "./axiosInstance"
const baseUrl = import.meta.env;




export const refreshAccessToken = async () => {
  const username = window.localStorage.getItem("username");
  const password = window.localStorage.getItem("password");
  const Refreshtoken = window.localStorage.getItem("refresh_token")

  if (!username || !password) throw new Error("Missing user credentials");

  const payload = {
    username,
    password,
  };

  try {
    const response = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/auth/refresh`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
         "Authorization": `Bearer ${Refreshtoken}`
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!data || data.error) {
      throw new Error(data.message || "Failed to refresh token");
    }

    window.localStorage.setItem("token", data.data.access_token);

    console.log("Token refreshed successfully");

    return data.data.access_token;
  } catch (error) {
    console.error("Failed to refresh token:", error.message);
    throw error;
  }
};


export const loginDetails = async (payload) => {
  const response = await axiosInstance.post('/auth/login', payload);
  return response.data.data;
};


// export const loginDetails = async (payload) => {
//   try {
//     const response = await fetch(
//       `${baseUrl.VITE_LINGUIST_BACKEND_URL}/auth/login`,
//       {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(payload),
//       }
//     );

//     const jsonData = await response.json();
//     // console.log(jsonData,"Data")

//     if (jsonData.error) {
//       throw new Error(jsonData.message);
//     }

//     return jsonData.data;
//   } catch (error) {
//     console.error("Login failed:", error.message);
//     throw error;
//   }
// };

// HomePage API
export const getUserProgress = async (userId) => {
  try {
    let accessToken = window.localStorage.getItem("token");
    const response = await fetch(
      `${baseUrl.VITE_LINGUIST_BACKEND_URL}/users/${userId}/progress`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );
    if (response.status === 401) {
      accessToken = await refreshAccessToken();
      return getUserProgress(userId);
    }
    if (!response.ok) {
      throw new Error("Error fetching user progress");
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching user progress", error);
    throw error;
  }
};

export const profilegrading = async (userLevel) => {
  try {
    let accessToken = window.localStorage.getItem("token")
    const response = await fetch(
      `${baseUrl.VITE_LINGUIST_BACKEND_URL}/users/${userLevel}/cefr-level`,
      {
        method: "GET",
        headers: {
          "content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`
          
        },
        // body: JSON.stringify({
        //   user_id: parseInt(userLevel),
        // }),
      }
    );
    if (response.status === 401) {
      accessToken = await refreshAccessToken()
      return profilegrading(userLevel)
    }
    if(!response.ok){
      throw new error("Error in featching CEFR Rating")
    }
    return await response.json();
  } catch (error) {
    console.error("Erro during the fetching ", error);
    throw error;
  }
};

export const getDashboardDetails = async (user_Id) => {
  
  try {
    let accessToken = window.localStorage.getItem("token")

    const response = await fetch(
      `${baseUrl.VITE_LINGUIST_BACKEND_URL}/users/${user_Id}/performance`,
      {
        method: "GET",
        headers: {
          "content-Type": "application/json",
           Authorization: `Bearer ${accessToken}`
        },
      }
    );
    if (response.status === 401) {
      accessToken = await refreshAccessToken();
      return getDashboardDetails(user_Id);
    }

    if (!response.ok) {
      throw new Error("Error in fetching dashboard details");
    }
    return await response.json();
  } catch (error) {
    console.error("error during the fetching dash board details ", error);
    throw error;
  }
};



// Chat Page
export const fetchParagraphDetails = async (stories_id) => {
  let accessToken = window.localStorage.getItem("token")

  try {
    const user_id = window.sessionStorage.getItem("user_id");
    const response = await fetch(
      `${baseUrl.VITE_LINGUIST_BACKEND_URL}/stories/${stories_id}/paragraphs?user_id=${user_id}`,

      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
           Authorization: `Bearer ${accessToken}`

        },
      }
    );
    if (response.status === 401) {
      accessToken = await refreshAccessToken();
      return fetchParagraphDetails(stories_id);
    }
   if(!response.ok){
    throw new Error("Error in fetching Paragraph details")
   }
   return await response.json();

    // if (response.ok) {
    //   const jsonData = await response.json();
    //   return jsonData;
    // } else {
    //   console.error("Error fetching story:", response.statusText);
    //   return null;
    // }
  } 
  catch (error) {
    console.error("Error during fetch process:", error);
    throw error;
  }
};

// export const fetchParagraphDetails = async (stories_id) => {
//   try {
//     let accessToken = window.localStorage.getItem("token");

//     let response = await fetch(
//       `${baseUrl.VITE_LINGUIST_BACKEND_URL}/stories/${stories_id}/paragraphs?user_id=${user_id}`,
//       {
//         method: "GET",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${accessToken}`,
//         },
//       }
//     );

//     if (response.status === 401) {
//       accessToken = await refreshAccessToken();
//       if (!accessToken) {
//         throw new Error("Failed to refresh token");
//       }

//       response = await fetch(
//         `${baseUrl.VITE_LINGUIST_BACKEND_URL}/stories/${stories_id}/paragraphs?user_id=${user_id}`,
//         {
//           method: "GET",
//           headers: {
//             "Content-Type": "application/json",
//             Authorization: `Bearer ${accessToken}`,
//           },
//         }
//       );
//     }

//     if (!response.ok) {
//       throw new Error("Error fetching paragraph details");
//     }

//     return await response.json();
//   } catch (error) {
//     console.error("Error during fetch process:", error);
//     throw error;
//   }
// };




export const generateAudio = (textToSpeak) => {
  try {
    if ("speechSynthesis" in window) {
      speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(textToSpeak);

      utterance.pitch = 1;
      utterance.rate = 0.9;
      utterance.volume = 1;

      speechSynthesis.speak(utterance);

      utterance.onend = () => {
        // console.log("Speech finished");
      };

      utterance.onerror = (event) => {
        console.error("Speech synthesis error:", event.error);
      };
    } else {
      console.error("Speech Synthesis API not supported in this browser");
    }
  } catch (error) {
    console.error("Error generating audio:", error);
  }
};
export const stopAudio = () => {
  if ("speechSynthesis" in window) {
    speechSynthesis.cancel();
  }
};


export const fetchChatResponse = async (payload) => {
  try {
    let accessToken = window.localStorage.getItem("token");

    const response = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload)
    });

    if (response.status === 401) {
      accessToken = await refreshAccessToken();
      return fetchChatResponse(payload);
    }

    if (!response.ok) {
      throw new Error(`Error fetching chat content: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Error fetching chat response:", error);
    throw error;
  }
};

/**
 * Streaming chat — calls /chat/stream and invokes callbacks as tokens arrive.
 * onToken(chunk: string) — called for each streamed word/token
 * onDone(meta: object)   — called once with the final metadata payload
 */
export const fetchChatResponseStream = async (payload, onToken, onDone) => {
  let accessToken = window.localStorage.getItem("token");
  const response = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/chat/stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
    body: JSON.stringify(payload),
  });

  if (response.status === 401) {
    accessToken = await refreshAccessToken();
    return fetchChatResponseStream(payload, onToken, onDone);
  }
  if (!response.ok) throw new Error(`Stream error: ${response.statusText}`);

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop(); // keep incomplete line
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const json = line.slice(6).trim();
      if (!json) continue;
      try {
        const event = JSON.parse(json);
        if (event.error) throw new Error(event.error);
        if (event.done) { onDone(event); }
        else if (event.token !== undefined) { onToken(event.token); }
      } catch (e) {
        console.warn("SSE parse error:", e);
      }
    }
  }
};








export const sendQuizScore = async (score) => {
  try {
    let accessToken = window.localStorage.getItem("token");

    const response = await fetch(
      `${baseUrl.VITE_LINGUIST_BACKEND_URL}/quiz/submit-mcq`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          user_id: parseInt(window.sessionStorage.getItem("user_id")),
          score: parseInt(score),
        }),
      }
    );

    if (response.status === 401) {
      accessToken = await refreshAccessToken();
      return sendQuizScore(score);
    }

    if (!response.ok) {
      throw new Error(`Error submitting quiz score: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Quiz score API Error", error);
    throw error;
  }
};

// ── Admin APIs ───────────────────────────────────────────────────────────────
const adminToken = () => window.localStorage.getItem("token");
const adminHeaders = () => ({ "Content-Type": "application/json", Authorization: `Bearer ${adminToken()}` });

export const adminGetOverview = async () => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/overview`, { headers: adminHeaders() });
  if (!r.ok) throw new Error("Failed to fetch overview");
  return r.json();
};

export const adminGetUsers = async () => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/users`, { headers: adminHeaders() });
  if (!r.ok) throw new Error("Failed to fetch users");
  return r.json();
};

export const adminCreateUser = async (data) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/users`, {
    method: "POST", headers: adminHeaders(), body: JSON.stringify(data)
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminBulkUpload = async (file) => {
  const fd = new FormData(); fd.append("file", file);
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/users/bulk-upload`, {
    method: "POST", headers: { Authorization: `Bearer ${adminToken()}` }, body: fd
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminUpdateUser = async (userId, data) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/users/${userId}`, {
    method: "PUT", headers: adminHeaders(), body: JSON.stringify(data)
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminDeleteUser = async (userId) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/users/${userId}`, {
    method: "DELETE", headers: adminHeaders()
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminGetStudentPerformance = async (userId) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/users/${userId}/performance`, { headers: adminHeaders() });
  if (!r.ok) throw new Error("Failed to fetch performance");
  return r.json();
};

// ── Admin Story APIs ──────────────────────────────────────────────────────────

export const adminGetStories = async (level = null) => {
  const url = level
    ? `${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories?level=${encodeURIComponent(level)}`
    : `${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories`;
  const r = await fetch(url, { headers: adminHeaders() });
  if (!r.ok) throw new Error("Failed to fetch stories");
  return r.json();
};

export const adminBulkUploadStories = async (formData) => {
  const headers = { Authorization: `Bearer ${adminToken()}` }; // no Content-Type — let browser set multipart boundary
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/bulk-upload`, {
    method: "POST",
    headers,
    body: formData,
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminCreateStory = async (data) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories`, {
    method: "POST", headers: adminHeaders(), body: JSON.stringify(data)
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminUpdateStory = async (storyId, data) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/${storyId}`, {
    method: "PUT", headers: adminHeaders(), body: JSON.stringify(data)
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminDeleteStory = async (storyId) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/${storyId}`, {
    method: "DELETE", headers: adminHeaders()
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminGetParagraphs = async (storyId) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/${storyId}/paragraphs`, { headers: adminHeaders() });
  if (!r.ok) throw new Error("Failed to fetch paragraphs");
  return r.json();
};

export const adminAddParagraph = async (storyId, data) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/${storyId}/paragraphs`, {
    method: "POST", headers: adminHeaders(), body: JSON.stringify(data)
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminUpdateParagraph = async (storyId, paraId, data) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/${storyId}/paragraphs/${paraId}`, {
    method: "PUT", headers: adminHeaders(), body: JSON.stringify(data)
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const adminDeleteParagraph = async (storyId, paraId) => {
  const r = await fetch(`${baseUrl.VITE_LINGUIST_BACKEND_URL}/admin/stories/${storyId}/paragraphs/${paraId}`, {
    method: "DELETE", headers: adminHeaders()
  });
  const json = await r.json();
  if (json.error) throw new Error(json.message);
  return json;
};

export const fetchQuizDetails = async (payload) => {
  try {
    let accessToken = window.localStorage.getItem("token");
    console.log(payload)
    const response = await fetch(
      `${baseUrl.VITE_LINGUIST_BACKEND_URL}/quiz/generate-mcq`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(payload ),
      }
    );

    // if (response.status === 401) {
    //   accessToken = await refreshToken();
    //   return fetchQuizDetails();
    // }

    if (!response.ok) {
      throw new Error(`Error fetching quiz details: ${response.statusText}`);
    }

    const jsonData = await response.json();
    const correctAnswerKey = jsonData.question_data.answer;
    const correctAnswerText = jsonData.question_data[correctAnswerKey]; 
    return {
      question: jsonData.question_data.question,
      options: [
        jsonData.question_data.option_1,
        jsonData.question_data.option_2,
        jsonData.question_data.option_3,
        jsonData.question_data.option_4,
      ],
      // correctAnswer: jsonData.question_data.answer,
      correctAnswer: correctAnswerText, 
      sessionId: jsonData.session_id,
    };
    
    
  } catch (error) {
    console.error("Error fetching quiz details:", error);
    throw error;
  }
};

