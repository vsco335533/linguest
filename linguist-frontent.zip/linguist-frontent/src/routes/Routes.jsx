/* eslint-disable react/prop-types */
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import LoginPage from "../pages/loginPage/LoginPage";
import HomePage from "../pages/homePage/HomePage";
import ChatPage from "../pages/chatPage/ChatPage";
import QuizPage from "../pages/quizPage/QuizPage";
import ChatPageIntro from "../pages/introToChatPage/ChatPageIntro";
import AdminLoginPage from "../pages/admin/AdminLoginPage";
import AdminDashboard from "../pages/admin/AdminDashboard";


const PrivateRoute = ({ element }) => {
  return window.sessionStorage.getItem("user_id") ? element : <Navigate to="/" />;
};

const AdminRoute = ({ element }) => {
  return window.localStorage.getItem("admin_user_id") ? element : <Navigate to="/admin/login" />;
};


const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Student routes */}
        <Route exact path="/" element={<LoginPage />} />
        <Route exact path="/HomePage" element={<PrivateRoute element={<HomePage />} />} />
        <Route exact path="/ChatPageIntro" element={<PrivateRoute element={<ChatPageIntro/>}/>}/>
        <Route exact path="/chatpage" element={<PrivateRoute element={<ChatPage />} />} />
        <Route exact path="/quizPage" element={<PrivateRoute element={<QuizPage/>} />} />
        {/* Admin routes */}
        <Route exact path="/admin/login" element={<AdminLoginPage />} />
        <Route exact path="/admin/dashboard" element={<AdminRoute element={<AdminDashboard />} />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
